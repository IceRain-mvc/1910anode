import path from 'path';
//全局的路径
export const userListPath = path.join(__dirname, '../datacenter/userList.json');
export const addUserListPath = path.join(__dirname, '../datacenter/addUserList.json');

